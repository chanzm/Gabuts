 <?php
//include("../conf/loadconfig.inc.php");

$dbLocation = 'mysql:dbname=indonesia_db_1;host=localhost';
$dbLocation_domain1 = 'mysql:dbname=indonesia_db_1;host=localhost';
$dbUser = 'root';
$dbPass = '';
$db = new PDO($dbLocation, $dbUser, $dbPass, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'utf8\''));
$db_domain1 = new PDO($dbLocation_domain1, $dbUser, $dbPass, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'utf8\''));

/*
$sql = 'SELECT id, CONCAT(kelurahan, " ", kodepos, " ", kota_kab) AS address 
FROM tbl_kodepos_copy 
WHERE latitude = 0
order by kota_kab';
*/

// $sql = "SELECT id, CONCAT(kelurahan, ' ', kota_kab) AS address 
// FROM tbl_kodepos_copy 
// WHERE LENGTH(level_4_short) = 5 AND level_4_short REGEXP '^[0-9]+$'
// order by kota_kab";

$sql='SELECT id,id_propinsi,kecamatan,CONCAT(kelurahan, " ", kodepos, " ", kota_kab) AS address ,
level_1_short,level_1_long,level_2_short,level_2_long,level_3_short,level_3_long,level_4_short,level_4_long,
latitude,longitude,northeast_lat,northeast_lng,southwest_lat,southwest_lng,formatted_address,place_id
	  FROM tbl_kodepos_copy WHERE latitude = 0 OR longitude = 0;'




// $sql='SELECT * FROM tbl_kodepos_copy WHERE latitude = 0 OR longitude = 0';
	  
$query = $db->prepare($sql);
$query->execute();

if ($query->errorCode() == '00000')
{
	$accounts = $query->fetchAll(PDO::FETCH_ASSOC);
}
else
{
	$query_errorInfo = $query->errorInfo();
	$error_message = __FILE__.'(line '.__LINE__.'): SQL Error - '.$query_errorInfo[2];
	echo $error_message;
}

$result = array();			
$json_array = array();

foreach ($accounts as $account_index=>$account)
{
	array_push($json_array, $account);
}
//$result["rows"] = $json_array;
echo json_encode($json_array);

exit;

/*
$result = array();			
$json_array = array();
$data = mysqli_query($con, "SELECT CONCAT(kelurahan, ", ", kota_kab, ", ", kodepos) AS Address FROM tbl_kodepos");
while($row = mysqli_fetch_array($data)) {
	array_push($json_array, $row);
}
$result["rows"] = $json_array;
echo json_encode($result);

mysqli_close($con);
*/
?>