 <?php
//include("../conf/loadconfig.inc.php");

$dbLocation = 'mysql:dbname=indonesia_db_1;host=localhost';
$dbLocation_domain1 = 'mysql:dbname=indonesia_db_1;host=localhost';
$dbUser = 'root';
$dbPass = '';
$db = new PDO($dbLocation, $dbUser, $dbPass, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'utf8\''));
$db_domain1 = new PDO($dbLocation_domain1, $dbUser, $dbPass, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'utf8\''));

$sql = "update tbl_kodepos_copy set 
level_1_short = '".$_POST['level_1_short']."',
level_1_long = '".$_POST['level_1_long']."',
level_2_short = '".$_POST['level_2_short']."',
level_2_long = '".$_POST['level_2_long']."',
level_3_short = '".$_POST['level_3_short']."',
level_3_long = '".$_POST['level_3_long']."',
level_4_short = '".$_POST['level_4_short']."',
level_4_long = '".$_POST['level_4_long']."',
latitude = '".$_POST['latitude']."',
longitude = '".$_POST['longitude']."',
northeast_lat = '".$_POST['northeast_lat']."',
northeast_lng = '".$_POST['northeast_lng']."',
southwest_lat = '".$_POST['southwest_lat']."',
southwest_lng = '".$_POST['southwest_lng']."',
formatted_address = '".$_POST['formatted_address']."',
place_id = '".$_POST['place_id']."'
where id = ".$_POST['id'];

$query = $db->prepare($sql);


if ($query->execute()) { 
   echo 'ok';
} else {
   echo 'fail';
}

?>